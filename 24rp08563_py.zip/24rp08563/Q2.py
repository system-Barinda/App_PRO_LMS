# Student: System Sylvere BARINDA
# Registration Number: 24rp08563
# Class: C
# Question 2: Study Hours and Examination Performance

import numpy as np
from scipy import stats
import matplotlib.pyplot as plt

study_hours = np.array([2, 3, 4, 5, 6, 7, 8, 9])
marks = np.array([45, 50, 60, 65, 75, 80, 90, 95])

correlation, p_value = stats.pearsonr(study_hours, marks)
print("QUESTION 2: STUDY HOURS AND EXAMINATION PERFORMANCE")
print("Pearson correlation:", round(correlation, 4))
print("P-value:", f"{p_value:.6g}")
strength = "very strong" if abs(correlation) >= 0.8 else "strong" if abs(correlation) >= 0.6 else "moderate" if abs(correlation) >= 0.4 else "weak"
direction = "positive" if correlation > 0 else "negative"
print(f"Interpretation: There is a {strength} {direction} linear relationship.")
print("The p-value is below 0.05, so the relationship is statistically significant." if p_value < 0.05 else "The p-value is not below 0.05, so the relationship is not statistically significant.")

plt.scatter(study_hours, marks, color="blue")
plt.title("Study Hours and Examination Marks")
plt.xlabel("Study hours")
plt.ylabel("Examination marks")
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig("Q2_scatter_plot.png", dpi=150)
plt.show()
