# Student: System Sylvere BARINDA
# Registration Number: 24rp08563
# Class: C
# Question 10: Machine Learning Model Comparison

from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score

iris = load_iris()
X = iris.data
y = iris.target

print("QUESTION 10: MACHINE LEARNING MODEL COMPARISON")
print("Features:", iris.feature_names)
print("Classes:", iris.target_names)
print("Dataset dimensions:", X.shape)

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

models = {
    "K-Nearest Neighbors": Pipeline([
        ("scaler", StandardScaler()),
        ("model", KNeighborsClassifier())
    ]),
    "Decision Tree": DecisionTreeClassifier(random_state=42),
    "Logistic Regression": Pipeline([
        ("scaler", StandardScaler()),
        ("model", LogisticRegression(max_iter=1000))
    ]),
}

scores = {}
for name, model in models.items():
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)
    scores[name] = accuracy_score(y_test, predictions)
    print(f"{name} accuracy: {scores[name]:.2%}")

best_model = max(scores, key=scores.get)
print(f"Best test result: {best_model} ({scores[best_model]:.2%})")
print("Limitation: one train/test split may give a result that depends on which records entered the test set. Cross-validation gives a more reliable estimate.")
