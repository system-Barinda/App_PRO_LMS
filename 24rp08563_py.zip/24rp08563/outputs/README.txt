Run Q1.py through Q10.py from the assignment folder. The ZIP includes captured outputs after validation. Q2 and Q4 generate plot images in the plots folder when run.
