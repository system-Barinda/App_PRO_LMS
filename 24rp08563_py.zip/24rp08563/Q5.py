# Student: System Sylvere BARINDA
# Registration Number: 24rp08563
# Class: C
# Question 5: Health Center Distance Analysis

import math

patient = [4, 5]
health_centers = {
    "Center A": [8, 9],
    "Center B": [5, 7],
    "Center C": [12, 4],
    "Center D": [3, 3],
}

# Euclidean distance gives straight-line distance in kilometres.
distances = {}
for name, coordinates in health_centers.items():
    distance = math.sqrt(
        (patient[0] - coordinates[0])**2 +
        (patient[1] - coordinates[1])**2
    )
    distances[name] = distance

sorted_centers = sorted(distances.items(), key=lambda item: item[1])

print("QUESTION 5: HEALTH CENTER DISTANCE ANALYSIS")
print("Distances (km):")
for name, distance in distances.items():
    print(f"{name}: {distance:.2f} km")
print("\\nCenters sorted from nearest to farthest:")
for name, distance in sorted_centers:
    print(f"{name}: {distance:.2f} km")
nearest_name, nearest_distance = sorted_centers[0]
print(f"Nearest health center: {nearest_name} at {nearest_distance:.2f} km")
