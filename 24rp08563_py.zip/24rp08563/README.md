# Python and Fundamentals of Artificial Intelligence Assignment

**Student:** System Sylvere BARINDA  
**Registration number:** 24rp08563  
**Class:** C

## Contents
- `Q1.py` through `Q10.py`: separate solutions for all ten questions.
- `requirements.txt`: Python libraries needed.
- `outputs/`: captured program outputs and generated plots (after running the scripts).

## Setup in Visual Studio Code
1. Install Python 3.
2. Open this folder in Visual Studio Code.
3. Open the terminal and create/activate a virtual environment if desired:
   - Windows: `py -m venv .venv` then `.venv\\Scripts\\activate`
   - macOS/Linux: `python3 -m venv .venv` then `source .venv/bin/activate`
4. Install libraries: `python -m pip install -r requirements.txt`
5. Run each file, for example: `python Q1.py`.

Run the scripts from this folder so the plots from Q2 and Q4 are saved here.

## Notes
- Each script includes the student's name, registration number, class, question title, and explanatory comments.
- Q1 uses population variance and population standard deviation (`numpy.var` and `numpy.std` defaults); SciPy kurtosis is Fisher's excess kurtosis.
- Q9 is an educational dataset exercise only, not a medical diagnostic tool.
