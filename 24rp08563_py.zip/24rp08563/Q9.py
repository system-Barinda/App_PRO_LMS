# Student: System Sylvere BARINDA
# Registration Number: 24rp08563
# Class: C
# Question 9: Breast Cancer Classification Using Built-in Dataset
# Educational demonstration only; this model must not be used for medical diagnosis.

from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, precision_score, recall_score, confusion_matrix

dataset = load_breast_cancer()
X = dataset.data
y = dataset.target

print("QUESTION 9: BREAST CANCER CLASSIFICATION")
print("Dataset dimensions (rows, columns):", X.shape)
print("Features:", dataset.feature_names)
print("Classes:", dataset.target_names)

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# Scaling is fitted only on training data through the Pipeline to avoid data leakage.
model = Pipeline([
    ("scaler", StandardScaler()),
    ("classifier", LogisticRegression(max_iter=10000))
])
model.fit(X_train, y_train)
predictions = model.predict(X_test)

print(f"Accuracy: {accuracy_score(y_test, predictions):.4f}")
print(f"Precision: {precision_score(y_test, predictions):.4f}")
print(f"Recall: {recall_score(y_test, predictions):.4f}")
print("Confusion matrix (rows=actual, columns=predicted):")
print(confusion_matrix(y_test, predictions))
print("Why accuracy alone is insufficient: it can hide missed malignant cases or unequal errors. Recall and the confusion matrix help show false negatives and other mistakes.")
