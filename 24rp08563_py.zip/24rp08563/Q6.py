# Student: System Sylvere BARINDA
# Registration Number: 24rp08563
# Class: C
# Question 6: Student Examination Performance Prediction

import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error

study_hours = np.array([[1], [2], [3], [4], [5], [6], [7], [8], [9], [10]])
exam_marks = np.array([35, 40, 45, 55, 60, 65, 75, 80, 85, 95])

X_train, X_test, y_train, y_test = train_test_split(
    study_hours, exam_marks, test_size=0.2, random_state=42
)

model = LinearRegression()
model.fit(X_train, y_train)
predictions = model.predict(X_test)
mae = mean_absolute_error(y_test, predictions)
predicted_6_5 = model.predict(np.array([[6.5]]))[0]

print("QUESTION 6: STUDENT EXAMINATION PERFORMANCE PREDICTION")
print("Test study hours:", X_test.ravel())
print("Actual test marks:", y_test)
print("Predicted test marks:", np.round(predictions, 2))
print(f"Mean Absolute Error (MAE): {mae:.2f} marks")
print("Interpretation: On average, predictions differ from actual test marks by about the MAE value.")
print(f"Predicted mark for 6.5 study hours: {predicted_6_5:.2f}")
