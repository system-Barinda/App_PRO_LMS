# Student: System Sylvere BARINDA
# Registration Number: 24rp08563
# Class: C
# Question 4: Agricultural Production Optimization

import numpy as np
from scipy.optimize import minimize_scalar
import matplotlib.pyplot as plt

def production(x):
    """Return predicted production for fertilizer amount x (kg)."""
    return -2 * x**2 + 80 * x + 500

# Bounded minimization of the negative function gives its maximum.
result = minimize_scalar(lambda x: -production(x), bounds=(0, 40), method="bounded")
optimal_fertilizer = result.x
maximum_production = production(optimal_fertilizer)

print("QUESTION 4: AGRICULTURAL PRODUCTION OPTIMIZATION")
print(f"Optimal fertilizer: {optimal_fertilizer:.2f} kg")
print(f"Maximum predicted production: {maximum_production:.2f}")

x_values = np.linspace(0, 40, 200)
plt.plot(x_values, production(x_values), label="P(x) = -2x² + 80x + 500")
plt.scatter([optimal_fertilizer], [maximum_production], color="red", label="Maximum")
plt.annotate(f"({optimal_fertilizer:.1f}, {maximum_production:.1f})",
             (optimal_fertilizer, maximum_production), xytext=(10, -20),
             textcoords="offset points")
plt.xlabel("Fertilizer (kg)")
plt.ylabel("Predicted production")
plt.title("Agricultural Production Function")
plt.legend()
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig("Q4_production_plot.png", dpi=150)
plt.show()
