# Student: System Sylvere BARINDA
# Registration Number: 24rp08563
# Class: C
# Question 8: Customer Segmentation Using K-Means

import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans

data = {
    "Customer": ["C1", "C2", "C3", "C4", "C5", "C6", "C7", "C8", "C9"],
    "Spending_RWF": [20000, 25000, 30000, 80000, 85000, 90000, 150000, 160000, 170000],
    "Visits": [2, 3, 4, 10, 12, 11, 20, 22, 21],
}
df = pd.DataFrame(data)

# Standardize the two numerical columns before clustering.
features = df[["Spending_RWF", "Visits"]]
scaler = StandardScaler()
scaled_features = scaler.fit_transform(features)

kmeans = KMeans(n_clusters=3, random_state=42, n_init=10)
df["Cluster"] = kmeans.fit_predict(scaled_features)

print("QUESTION 8: CUSTOMER SEGMENTATION USING K-MEANS")
print("\\nCustomer data with cluster labels:")
print(df.to_string(index=False))
print("\\nCluster interpretation (average values):")
summary = df.groupby("Cluster")[["Spending_RWF", "Visits"]].mean().round(2)
print(summary.to_string())
print("\\nInterpretation: Clusters with lower averages represent lower spending/visit activity; higher averages represent more active, higher-spending customers. Cluster numbers are labels, not rankings.")
