# Student: System Sylvere BARINDA
# Registration Number: 24rp08563
# Class: C
# Question 1: Student Performance Statistical Analysis

import numpy as np
from scipy import stats

marks = np.array([45, 67, 78, 89, 56, 90, 72, 67, 84, 95, 58, 76, 81, 67, 93])

mean_value = np.mean(marks)
variance_value = np.var(marks)  # Population variance
skewness_value = stats.skew(marks)
kurtosis_value = stats.kurtosis(marks)  # Fisher's excess kurtosis
mode_result = stats.mode(marks, keepdims=False)
std_deviation = np.std(marks)  # Population standard deviation

print("QUESTION 1: STUDENT PERFORMANCE STATISTICAL ANALYSIS")
print(f"Mean: {mean_value:.2f}")
print(f"Variance: {variance_value:.2f}")
print(f"Skewness: {skewness_value:.4f}")
print(f"Kurtosis (excess): {kurtosis_value:.4f}")
print(f"Mode: {mode_result.mode} (frequency: {mode_result.count})")
print(f"Standard deviation: {std_deviation:.2f}")

if skewness_value > 0.5:
    shape = "positively (right) skewed"
elif skewness_value < -0.5:
    shape = "negatively (left) skewed"
else:
    shape = "approximately symmetrical"
print(f"Interpretation: The marks are {shape}.")
print("Kurtosis interpretation: positive = heavier tails; negative = lighter tails than a normal distribution.")
