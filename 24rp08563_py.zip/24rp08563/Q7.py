# Student: System Sylvere BARINDA
# Registration Number: 24rp08563
# Class: C
# Question 7: Student Pass/Fail Classification

import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score

# Fail is encoded as 0 and Pass as 1.
X = np.array([
    [2, 50], [3, 55], [4, 60], [5, 65], [6, 70],
    [7, 75], [8, 80], [9, 85], [3, 60], [8, 90]
])
y = np.array([0, 0, 0, 0, 1, 1, 1, 1, 0, 1])

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

model = DecisionTreeClassifier(random_state=42)
model.fit(X_train, y_train)
test_predictions = model.predict(X_test)
accuracy = accuracy_score(y_test, test_predictions)
new_prediction = model.predict(np.array([[6, 78]]))[0]
result_text = "Pass" if new_prediction == 1 else "Fail"

print("QUESTION 7: STUDENT PASS/FAIL CLASSIFICATION")
print("Test actual labels:", y_test)
print("Test predicted labels:", test_predictions)
print(f"Test accuracy: {accuracy:.2%}")
print(f"Prediction for 6 study hours and 78% attendance: {result_text}")
