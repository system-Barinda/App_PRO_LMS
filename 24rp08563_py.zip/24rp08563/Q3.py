# Student: System Sylvere BARINDA
# Registration Number: 24rp08563
# Class: C
# Question 3: Supermarket Product Price Determination

import numpy as np
from scipy.linalg import solve

# Let n = notebook price, p = pen price, and c = pencil price.
# Equations: 2n + 3p + c = 2900; 3n + 2p + 2c = 3400; n + 4p + 3c = 3100.
A = np.array([[2, 3, 1], [3, 2, 2], [1, 4, 3]], dtype=float)
b = np.array([2900, 3400, 3100], dtype=float)

prices = solve(A, b)
notebook_price, pen_price, pencil_price = prices

print("QUESTION 3: SUPERMARKET PRODUCT PRICE DETERMINATION")
print(f"Notebook price: RWF {notebook_price:.2f}")
print(f"Pen price: RWF {pen_price:.2f}")
print(f"Pencil price: RWF {pencil_price:.2f}")

# Verify each customer's total by substituting the calculated prices.
calculated_totals = A @ prices
for customer, total, expected in zip(["A", "B", "C"], calculated_totals, b):
    print(f"Customer {customer}: calculated RWF {total:.2f}; expected RWF {expected:.2f}; match = {np.isclose(total, expected)}")
